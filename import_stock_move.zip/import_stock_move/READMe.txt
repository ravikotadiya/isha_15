Added import sample file download functionality.
